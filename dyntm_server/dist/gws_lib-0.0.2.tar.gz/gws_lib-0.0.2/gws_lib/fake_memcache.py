class memcache:
    @staticmethod
    def get(*args,**keyargs):
        return None
    @staticmethod
    def set(*args,**keyargs):
        return None
    @staticmethod
    def add(*args,**keyargs):
        return None
    @staticmethod
    def delete(*args,**kwargs):
        return None
