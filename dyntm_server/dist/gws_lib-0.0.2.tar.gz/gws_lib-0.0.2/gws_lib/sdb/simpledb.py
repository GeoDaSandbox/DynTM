""" A basic libary for making authenticated requests to Amazon Web Services' SimpleDB """

from urlparse import urlparse,parse_qs
from urllib import quote,urlencode
from urllib2 import Request,urlopen
import unittest
import time,base64,hmac,hashlib
import re

class AWS_SimpleDB:
    # Endpoints as of May 13th 2010. Source: http://docs.amazonwebservices.com/AmazonSimpleDB/latest/DeveloperGuide/
    ENDPOINTS = {"us-east":"sdb.amazonaws.com",
                 "us-west":"sdb.us-west-1.amazonaws.com",
                 "eu-west":"sdb.eu-west-1.amazonaws.com",
                 "ap-southeast":"sdb.ap-southeast-1.amazonaws.com"}
    def __init__(self, accesskeyid, accesskey, region='us-east'):
        self.endpoint = self.ENDPOINTS[region]
        self.accesskeyid = accesskeyid
        self.accesskey = accesskey#.encode('UTF-8')
    def sign_request(self,request):
        """ Signs a urllib2.Request object """
        return {"GET":self._sign_get,"POST":self._sign_post}[request.get_method()](request)
    def old_sign_get(self,request):
        """ Signs a urllib2.Request object using the GET method """
        url = urlparse(request.get_full_url())
        string2sign = "GET\n"
        string2sign+= request.get_host().lower() + "\n"
        string2sign+= url.path + "\n"
        string2sign+= self.canonicalizeQueryString(parse_qs(url.query))
    def _sign_get(self,cqs):
        """ Signs a canonicalized QueryString as a GET request """
        string2sign = "GET\n"
        string2sign+= self.endpoint + "\n/\n"
        string2sign+= cqs
        string2sign = string2sign.encode('UTF-8') #ASCII
        return quote(base64.b64encode(hmac.new(self.accesskey,string2sign,hashlib.sha256).digest()))
    @staticmethod
    def canonicalizeQueryString(query):
        keys = query.keys()
        keys.sort()
        return '&'.join([quote(k).replace('%7E','~')+'='+quote(query[k]).replace('%7E','~') for k in keys])
    def get_item(self,domain,itemname):
        """ https://sdb.amazonaws.com/
            ?Action=GetAttributes
            &AWSAccessKeyId=[valid access key id]
            &DomainName=MyDomain
            &ItemName=JumboFez
            &SignatureVersion=2
            &SignatureMethod=HmacSHA256
            &Timestamp=2010-01-25T15%3A03%3A07-07%3A00
            &Version=2009-04-15
            &Signature=[valid signature]
        """
        query = {'Action':'GetAttributes',\
                 'AWSAccessKeyId':self.accesskeyid,\
                 'DomainName':domain,\
                 'ItemName':itemname,\
                 'SignatureVersion':'2',\
                 'SignatureMethod':'HmacSHA256',\
                 'Timestamp':time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),\
                 'Version':'2009-04-15'}
        cqs = self.canonicalizeQueryString(query)
        qs = cqs+"&Signature="+self._sign_get(cqs)
        r = urlopen(Request('http://'+self.endpoint+'/?'+qs)).read()
        #names = [p.split('<Value>')[0].split('</N')[0] for p in r.split('<Attribute><Name>') if p.startswith('dat')]
        #values = [p.split('<Value>')[1].split('</Value>')[0] for p in r.split('<Attribute><Name>') if p.startswith('dat')]
        #parts = dict(zip(names,values))
        #dat = ''
        #for i in xrange(len(names)):
        #    dat+=parts['dat%d'%i]
        #dat = zlib.decompress(base64.b64decode(dat))
        return dict(re.findall('<Attribute><Name>(.*?)</Name><Value>(.*?)</Value>',r))
    get_attributes = get_item
        
class Test_AWS_SimpleDB(unittest.TestCase):
    def setUp(self):
        self.accesskeyid = open(os.path.expanduser('~/.ec2/accesskeyid'),'r').read().strip()
        self.accesskey = open(os.path.expanduser('~/.ec2/accesskey'),'r').read().strip()
    def test_sign_request(self):
        sdb = AWS_SimpleDB(self.accesskeyid,self.accesskey)
        item_name = 'tile8k_000001.dat'
        domain = 'tiles'
        r = sdb.get_item(domain,item_name)
        self.assertEqual(hashlib.md5(r[r.index('dat5'):r.index('dat5')+1000]).hexdigest(),'0eb1563c74efe5174fba919f2bdd00f9')

if __name__=='__main__':
    import os.path
    suite = unittest.TestLoader().loadTestsFromTestCase(Test_AWS_SimpleDB)
    runner = unittest.TextTestRunner()
    runner.run(suite)

    accesskeyid = open(os.path.expanduser('~/.ec2/accesskeyid'),'r').read().strip()
    accesskey = open(os.path.expanduser('~/.ec2/accesskey'),'r').read().strip()
    sdb = AWS_SimpleDB(accesskeyid,accesskey)

    
