""" A basic libary for making authenticated requests to Amazon Web Services' S3 Service """

import sys
from urlparse import urlparse,parse_qs
from urllib import quote,urlencode
import urllib2
from urllib2 import Request,urlopen
import unittest
import time,base64,hmac,hashlib
from wsgiref.handlers import format_date_time
import re

class PutRequest(urllib2.Request):
    def get_method(self):
        return "PUT"
class PostRequest(urllib2.Request):
    def get_method(self):
        return "POST"

class AWS_S3:
    # Endpoints as of May 13th 2010. Source: http://docs.amazonwebservices.com/AmazonS3/latest/dev/index.html
    ENDPOINTS = {"us-east":"s3.amazonaws.com",
                 "us-west":"s3-us-west-1.amazonaws.com",
                 "eu-west":"s3-eu-west-1.amazonaws.com",
                 "ap-southeast":"s3-ap-southeast-1.amazonaws.com"}
    def __init__(self, accesskeyid, accesskey, region='us-east'):
        self.endpoint = self.ENDPOINTS[region]
        self.accesskeyid = accesskeyid
        self.accesskey = accesskey#.encode('UTF-8')
    @staticmethod
    def canonicalizeQueryString(query):
        keys = query.keys()
        keys.sort()
        return '&'.join([quote(k).replace('%7E','~')+'='+quote(query[k]).replace('%7E','~') for k in keys])
    def initiate_multipart_upload(self,objectName,bucketName="test_data.cloud.geodacenter.org"):
        """ POST /ObjectName?uploads HTTP/1.1
            Host: BucketName.s3.amazonaws.com
            Date: date
            Authorization: signatureValue
        """
        url = "/%s?uploads"%objectName
        date = format_date_time(time.time()).replace('GMT','+0000')
        string2sign = "POST\n"
        string2sign+= "\n"#no md5
        string2sign+= "\n"#no content-type, default is binary/octel-stream
        string2sign+= date+"\n"
        string2sign+= "/"+bucketName+url
        sig = base64.b64encode(hmac.new(self.accesskey,string2sign,hashlib.sha1).digest())
        auth = "AWS %s:%s"%(self.accesskeyid,sig)
        req = PostRequest("http://%s.%s%s"%(bucketName,self.endpoint,url))
        req.add_header('Authorization',auth)
        req.add_header('Date',date)
        try:
            u = urlopen(req)
            uploadId = re.findall('<UploadId>(.*?)</UploadId>',u.read())[0]
            return uploadId
        except:
            return False
        return False
    def upload_part(self,objectName,uploadID,partNumber,data,bucketName="test_data.cloud.geodacenter.org"):
        url = "/%s?partNumber=%d&uploadId=%s"%(objectName,partNumber,uploadID)
        date = format_date_time(time.time()).replace('GMT','+0000')
        #md5 = hashlib.md5(data).hexdigest()
        string2sign = "PUT\n"
        string2sign+= "\n"#no md5
        string2sign+= "binary/octel-stream\n"
        string2sign+= date+"\n"
        string2sign+= "/"+bucketName+url
        sig = base64.b64encode(hmac.new(self.accesskey,string2sign,hashlib.sha1).digest())
        auth = "AWS %s:%s"%(self.accesskeyid,sig)
        req = PutRequest("http://%s.%s%s"%(bucketName,self.endpoint,url),data)
        req.add_header('Authorization',auth)
        req.add_header('Date',date)
        req.add_header('Content-Length',len(data))
        req.add_header("Content-type","binary/octel-stream")
        #req.add_header('Content-MD5',md5)
        try:
            u = urlopen(req)
            etag = u.headers.dict['etag']
            return etag
        except:
            return False
        return False
    def complete_multipart_upload(self,objectName,uploadID,parts,bucketName="test_data.cloud.geodacenter.org"):
        s = "<CompleteMultipartUpload>\n"
        part = "  <Part>\n    <PartNumber>%d</PartNumber>\n    <ETag>%s</ETag>\n  </Part>\n"
        keys = parts.keys()
        keys.sort()
        for k in keys:
            s+=part%(k,parts[k])
        s+="</CompleteMultipartUpload>"

        url = "/%s?uploadId=%s"%(objectName,uploadID)
        date = format_date_time(time.time()).replace('GMT','+0000')
        string2sign = "POST\n"
        string2sign+= "\n"#no md5
        string2sign+= "binary/octel-stream\n"
        string2sign+= date+"\n"
        string2sign+= "/"+bucketName+url
        sig = base64.b64encode(hmac.new(self.accesskey,string2sign,hashlib.sha1).digest())
        auth = "AWS %s:%s"%(self.accesskeyid,sig)
        req = PostRequest("http://%s.%s%s"%(bucketName,self.endpoint,url),s)
        req.add_header('Authorization',auth)
        req.add_header('Date',date)
        req.add_header('Content-Length',len(s))
        req.add_header("Content-type","binary/octel-stream")
        u = urlopen(req)
        location = re.findall('<Location>(.*?)</Location>',u.read())
        if location:
            return location[0]
        else:
            return False
        
        
class Test_AWS_S3(unittest.TestCase):
    def setUp(self):
        self.accesskeyid = open(os.path.expanduser('~/.ec2/accesskeyid'),'r').read().strip()
        self.accesskey = open(os.path.expanduser('~/.ec2/accesskey'),'r').read().strip()
    def test_sign_request(self):
        s3 = AWS_S3(self.accesskeyid,self.accesskey)
        item_name = 'tile8k_000001.dat'
        domain = 'tiles'
        r = s3.get_item(domain,item_name)
        self.assertEqual(hashlib.md5(r[r.index('dat5'):r.index('dat5')+1000]).hexdigest(),'0eb1563c74efe5174fba919f2bdd00f9')

if __name__=='__main__':
    import os.path
    #suite = unittest.TestLoader().loadTestsFromTestCase(Test_AWS_S3)
    #runner = unittest.TextTestRunner()
    #runner.run(suite)

    accesskeyid = open(os.path.expanduser('~/.ec2/accesskeyid'),'r').read().strip()
    accesskey = open(os.path.expanduser('~/.ec2/accesskey'),'r').read().strip()
    s3 = AWS_S3(accesskeyid,accesskey)
    print "Getting MD5..."
    """
    bigfile = open("/Users/charlie/Documents/data/tracts/ntracts_Dissolve.shp",'rb')
    md5 = hashlib.md5()
    dat = bigfile.read(2**16)
    while dat:
        md5.update(dat)
        dat = bigfile.read(2**16)
    bigfile.seek(0)
    print "MD5:", md5.hexdigest()
    key = md5.hexdigest()
    upload_id = s3.initiate_multipart_upload(key)
    print "upload id:",upload_id
    CHUNK = 12*1024*1024
    dat = bigfile.read(CHUNK)
    parts = {}
    part = 1
    print "Start Upload...."
    while dat:
        t0 = time.time()
        etag = s3.upload_part(key,upload_id,part,dat)
        t1 = time.time()
        if etag:
            sec = t1-t0
            kbps = ((CHUNK/1024.0)/sec)
            print "Part %d (%s): %0.2f kB/s"%(part,etag,kbps)
            parts[part] = etag
            dat = bigfile.read(CHUNK)
            part += 1
        else:
            print "Part %d failed to upload, trying again..."%part
    """
    parts = {1: '"410235fe6197d7770c1920597a0ab1d8"', 2: '"f47926e167ef733a9aae3758333afeb7"', 3: '"4ac09804c0d34d43b2ff0db146fb6bc8"', 4: '"c6a01609ce534ba07262029aec0520cb"', 5: '"1dab1253622facf2d04b5fb0b9bd0b62"', 6: '"bdd02f7f0bb7c9c263bcab7a15110f12"'}
    uploadID = '.SvVjUpgqu72rgu983iOYU9cIQGtleOUWnaad39C_WvXNDryamQhw.N9kqvMnsbDAJl8NCnmGhB2Z0f_zMa2yw--'
    key = 'bd203a498c58012fa21b7d6e66f1ea21'

