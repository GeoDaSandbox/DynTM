# Create your views here.
from geodaWebServices import WebService
from geodaWebServices.lib import db
from geodaWebServices.lib import memcache

